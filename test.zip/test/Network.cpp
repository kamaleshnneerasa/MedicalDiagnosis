#include "Network.h"
#include <cstdlib>

// The whole network represted as a list of nodes
int Network::addNode(Graph_Node node)
{
	Pres_Graph.push_back(node);
    nodePst[node.get_name()] = Pres_Graph.size()-1;
	return 0;
}
    
    
int Network::netSize()
{
	return Pres_Graph.size();
}

    // get the index of node with a given name
int Network::get_index(string val_name)
{
    list<Graph_Node>::iterator listIt;
    int count=0;
    for(listIt=Pres_Graph.begin();listIt!=Pres_Graph.end();listIt++)
    {
        if(listIt->get_name().compare(val_name)==0)
            return count;
        count++;
    }
    return -1;
}

// get the node at nth index
list<Graph_Node>::iterator Network::get_nth_node(int n)
{
    list<Graph_Node>::iterator listIt;
    int count=0;
    for(listIt=Pres_Graph.begin();listIt!=Pres_Graph.end();listIt++)
    {
        if(count==n)
            return listIt;
        count++;
    }
    return listIt; 
}

//get the iterator of a node with a given name
list<Graph_Node>::iterator Network::search_node(string val_name)
{
    list<Graph_Node>::iterator listIt;
    for(listIt=Pres_Graph.begin();listIt!=Pres_Graph.end();listIt++)
    {
        if(listIt->get_name().compare(val_name)==0)
            return listIt;
    }
    
    cout<<"node not found\n";
    return listIt;
}

vector<int> Network::parentsPst(int n){
    std::vector<string> parents = get_nth_node(n)->get_Parents();
    std::vector<int> ans;

    for(int i =0; i<parents.size(); i++)
        ans.push_back(nodePst[parents[i]]);

    return ans;
}