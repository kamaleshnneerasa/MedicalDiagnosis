#include <string>
#include <vector>
#include <unordered_map>

using namespace std;

//extern vector<pair<vector<string>,float>> data;

class Graph_Node{

private:
	string Node_Name;  // Variable name 
	vector<int> Children; // Children of a particular node - these are index of nodes in graph.
	vector<string> Parents; // Parents of a particular node- note these are names of parents
	//vector<int> parentsPst;//parent nodes number in network 
	int nvalues;  // Number of categories a variable represented by this node can take
	vector<string> values; // Categories of possible values
	vector<float> CPT; // conditional probability table as a 1-d array . Look for BIF format to understand its meaning
	vector<int> knownFreq;
	unordered_map<int, int> unknownLineIndexInCPT;

public:
	// Constructor- a node is initialised with its name and its categories
    Graph_Node(string name,int n,vector<string> vals);
	string get_name();
	vector<int> get_children();
	vector<string> get_Parents();
	vector<float> get_CPT();
	int get_nvalues();
	vector<string> get_values();
	void set_CPT(vector<float> new_CPT);
    void set_Parents(vector<string> Parent_Nodes);
    int add_child(int new_child_index );
    int get_value_pst(string val);
    //void set_Parents_pst(vector<int> pst);
    void add_line(int l, bool known, int CPTindex);
    vector<int>* get_knownFreq();
    unordered_map<int, int>* get_unknownFreq();
};