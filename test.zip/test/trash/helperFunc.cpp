#include <random>
#include <string>
#include <vector>
#include <list>

using namespace std;

extern Network Alarm;

