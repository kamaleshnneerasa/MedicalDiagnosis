#include <iostream>
#include <list>
#include <string>
#include <vector>
#include <cstdlib>
#include <random>
#include <iterator>
#include "Network.h"
//#include "Graph_Node.h"

using namespace std;

void Estep(vector<pair<vector<string>,pair<float,string>>> &,int);
void Mstep(vector<pair<vector<string>,pair<float,string>>> &,int);
float randomFloat();
void initialize();
int getIndex(string,string,vector<string>);
pair<vector<pair<vector<string>,pair<float,string>>>,int> getData();
void output();
vector<float> randomList(int);

Network Alarm;

int main(){
    
    Alarm= Network::read_network();
    //cout<<"Flag1"<<"\n";
    pair<vector<pair<vector<string>,pair<float,string>>>,int> data1 = getData();
    vector<pair<vector<string>,pair<float,string>>> data = data1.first;
    //for(int i=0;i<data.size();i++){
        //if(i<200) cout<<"size at"<<i<<" is "<<(data[i].first).size()<<"\n";
    //}
    int size = data1.second;
    initialize();
    for(int i=0;i<Alarm.netSize();i++){
        list<Graph_Node>::iterator ptr = Alarm.get_nth_node(i);
        cout<<ptr->get_nvalues()<<"\n";
        vector<float> CPT = ptr->get_CPT();
        for(int i=0;i<CPT.size();i++) cout<<CPT[i];
        cout<<"------------------";
       /* for(int i=0;i<CPT.size()/ptr->get_nvalues;i++){
            for(int j=0;j<ptr->get_nvalues;j++){
                temp2 = temp2+CPT(1)
            }
        }*/
        cout<<"\n";
    }
    int numIter = 0;
    while(numIter<10){
        Estep(data,size);
        Mstep(data,size);
        cout<<numIter<<" ";
        numIter++;
    }
    output();
    return 0;
}
//We are calculating the data given the marginal distribultion
void Estep(vector<pair<vector<string>,pair<float,string>>> &data,int size){
    cout<<"Estep"<<"\n";
    int counter =0;
    for(vector<pair<vector<string>,pair<float,string>>>::iterator ptr = data.begin(); ptr != data.end(); ptr++){
        counter = counter+1;
        //cout<<"counter*: "<<counter<<"\n";
        if(ptr->second.first >= -0.1)  //This has been changed
            continue;
        int varPst = -1; 
        for(int i =0; i< (signed)ptr->first.size(); i++){
            if(ptr->first[i] == "\"?\""){
                varPst = i;
                break;
            }
        }
        list<Graph_Node>::iterator node =  Alarm.get_nth_node(varPst);
        int nValues = node->get_nvalues();

        for(int i = 0; i< nValues; i++){
            ptr++;
            //cout<<"counteri: "<<counter<<"------------\n";
            int index = getIndex(node->get_name(), node->get_values()[i], ptr->first);
            //cout<<index<<" "<<node->get_CPT().size()<<"*************\n";
            ptr->second.first = node->get_CPT()[index]; ///This has been changed
            //cout<<"counter\\: "<<counter<<"\n";
        }
    }
    cout<<"Estep"<<"\n";
}
//We are calculting the marginal distributions given the data
void Mstep(vector<pair<vector<string>,pair<float,string>>> &data,int size){
    cout<<"Mstep"<<"\n";
    list<Graph_Node> Pres_Graph = Alarm.Pres_Graph;
    list<Graph_Node>::iterator listIt;
    int index = -1;
    int counter = 0;
    for(listIt=Pres_Graph.begin();listIt!=Pres_Graph.end();listIt++){
        //cout<<"counter: "<<counter<<"\n";
        string var = listIt->get_name();
        int nvalues = listIt->get_nvalues();
        vector<string> parents = listIt->get_Parents();
        vector<float> CPT = listIt->get_CPT();
        for(int i=0;i<CPT.size();i++){
            CPT[i]=0;
        }
        int den = 0;
        cout<<"counter: "<<counter<<" "<<CPT.size()<<"\n";
        int prev =-1;
        for(int i=0;i<data.size();i++){
            vector<string> temp1 = data[i].first;
            //cout<<"size: "<<counter<<" "<<CPT.size()<<" "<<temp1.size()<<"\n";
            string valVar = (data[i].first)[counter];
            //cout<<"counter: "<<counter<<"\n";
            int z =-1;
            int weight = data[i].second.first;
            string trash = data[i].second.second; //////This line has been added
            if(trash!="\"?\""){
                index = getIndex(var,valVar,data[i].first);
                if(prev==index){
                    //cout<<"index: "<<index<<" counter"<<counter<<"\n";
                    vector<string> v1 = data[i-1].first;
                    vector<string> v2 = data[i].first;
                    //for(int k=0;k<v1.size();k++) cout<<v1[k];
                    //cout<<"\n";
                    //for(int k=0;k<v2.size();k++) cout<<v2[k];
                    //cout<<"\n";
                }
                CPT[index] = CPT[index]+weight;
                if(weight<0) cout<<"weight is,i value is,valVar "<<weight<<" "<<i<<" "<<valVar<<"\n";
                prev = index;
            }
            else {
                z = i;
            }
        }
        for(int i=0;i<CPT.size();i++){
            CPT[i] = CPT[i]/size;
            if(CPT[i]>1) cout<<"Variable is "<<var<<" size "<<size<<"data size "<<data.size()<<"\n";
            //cout<<"CPT is: "<<CPT[i]<<"\n";
        }
        listIt->set_CPT(CPT);
        counter = counter+1;
    }
    cout<<"Mstep"<<"\n";
}

float randomFloat()
{
    std::random_device dev;
    std::mt19937 rng(dev());
    std::uniform_int_distribution<std::mt19937::result_type> dist6(1,1000000); // distribution in range [1, 6]

    return (float)dist6(rng)/(float) 1000000 ;
}

vector<float> randomList (int n)
{
    //cout<<"randomList"<<"\n";
    vector<float> arr(n);
    float sum = 0;

    for(int i =0; i<(n-1); i++)
    {
        arr[i] = randomFloat();
        sum += arr[i];
    }

    if(sum <= 1)
    {
        arr[n-1] = 1 - sum;
        return arr;
    }

    float factor = (float)((int)sum + 1);
    sum = 0;

    for(int i =0; i<(n-1); i++)
    {
        arr[i] = arr[i]/factor;
        sum += arr[i];
    }

    arr[n-1] = 1 - sum;
    return arr;
    //cout<<"randomList"<<"\n";
}

void initialize()
{
    //cout<<"initialize"<<"\n";
    int size = Alarm.netSize();
    for(int i =0; i < size; i++)
    {
        list<Graph_Node>::iterator ptr = Alarm.get_nth_node(i);
        int CPTsize = ptr->get_CPT().size();
        int valuesCount = ptr->get_values().size();
        int parentsValues = CPTsize/valuesCount;

        vector<float> CPTupdate(CPTsize);
        //float sum = 0.0;

        for(int j =0; j < parentsValues; j++)
        {
            vector<float> temp = randomList(valuesCount);
            for(int k = 0; k < valuesCount; k++)
            {
                CPTupdate[k*parentsValues + j] = temp[k];
            }
        }
        ptr->set_CPT(CPTupdate);
    }
    //cout<<"initialize"<<"\n";
}

//It takes variable,Value_of_variable,data_instance and Alarm as input and returns the index in the CPT Table  
int getIndex(string var,string valVar,vector<string> instance){
    //cout<<"getIndex"<<"\n";
    int index = 0;
    list<Graph_Node>::iterator listIt1 = Alarm.search_node(var);
    int nvalues = listIt1->get_nvalues();
    vector<string> values = listIt1->get_values();
    vector<string> parents = listIt1->get_Parents();
    int nParents = parents.size();
    vector<int> parentSize;
    int temp=1;
    for(int i=nParents-1;i>=0;i--){
        int id = Alarm.get_index(parents[i]);
        list<Graph_Node>::iterator listIt = Alarm.search_node(parents[i]);
        int parentSize = listIt->get_nvalues();
        vector<string> parentValues = listIt->get_values();
        //cout<<"id of parent: "<<id<<"sizes "<<parentSize<<"\n";
        for(int j=0;j<parents[i].size();j++){
            if(parentValues[j]==instance[id]){
                index = index + j*temp;
                //cout<<"Hey index"<<index<<"\n";
                break;
            }
        }
        temp = temp*parentSize;
    }
    for(int i=0;i<nvalues;i++){
        if(values[i]==valVar){
            index = index + i*temp;
            break;
        }
    }
    return index;
    //cout<<"index----------------- "<<index<<"\n";
}

//Reads the data from the file and returns in a dataStructure
pair<vector<pair<vector<string>,pair<float,string>>>,int> getData(){
    ifstream inFile;
    inFile.open("records.dat");
    string val;
    vector<pair<vector<string>,pair<float,string>>> result;
    int numLines = 0;
    //cout<<"Flag2"<<"\n";
    if(inFile.is_open()){
        while(numLines<11100){
            int flag = -1;
            vector<string> instance;
            for(int i=0;i<37;i++){
                inFile>> val;
                if(numLines==0) cout<<val<<" "; 
                if(val=="\"?\""){
                    flag = i;
                } 
                instance.push_back(val);
            }
            //if(numLines == 0) cout<<"\n"<<instance.size()<<"size of instance \n";
            if(flag>=0){
                //if(numLines==0) cout<<"\n"<<instance.size()<<"size of instance \n";
                pair<vector<string>,pair<float,string>> p(instance,make_pair(-1.0,"\"?\""));
                //if(numLines==0) cout<<p.first.size();
                result.push_back(p);
                //if(numLines==0) cout<<result[0].first.size()<<"**********\n";
                list<Graph_Node>::iterator listIt = Alarm.get_nth_node(flag);
                vector<string> values = listIt->get_values();
                string name = listIt->get_name();
                for(int i=0;i<values.size();i++){
                    vector<string> temp = instance;
                    temp[flag] = values[i];
                    result.push_back({temp,make_pair(0,name)});
                }
                //if(numLines==0) cout<<result[0].first.size()<<"----------\n";
            }
            if(flag<0){
                //if(numLines==0) cout<<"Hey\n";
                result.push_back(make_pair(instance,make_pair(1,"No?")));
            }
            numLines = numLines+1;
            //if(numLines==1) cout<<result[0].first.size()<<" "<<numLines<<"\n";
        }
    }

    return make_pair(result,numLines);
} 

//Outputs the values to the file
void output(){
    ifstream inputFile("alarm.bif");
    ofstream outputFile("solved_alarm.bif");
    
    string line;
    string words;
    int networkSize = Alarm.netSize();
    list<Graph_Node>::iterator ptr = Alarm.get_nth_node(0);

    if(inputFile.is_open() && outputFile.is_open()){
        while(!inputFile.eof()){
            stringstream ss;
            getline(inputFile, line);
            ss.str(line);

            ss >> words;

            if(words.compare("table") == 0){
                outputFile << "\ttable ";

                for(int i =0; i<ptr->get_CPT().size(); i++){
                    outputFile << ptr->get_CPT()[i] << " ";
                }
                ptr++;
                outputFile << ";\n";
            } 
            else{
                outputFile << line << "\n"; 
            }           
        }
    }
}
/*
void initialize(Network Alarm,vector<pair<vector<string>,float>> data){
    list<Graph_Node> Pres_Graph = Alarm.Pres_Graph;
    list<Graph_Node>::Iterator listIt;
    int index = -1;
    counter = 0;
    for(listIt=Pres_Graph.begin();listIt!=Pres_Graph.end();listIt++){
        string var = listIt->get_name();
        int nvalues = listIt->get_nvalues();
        vector<float> CPT = listIt->getCPT();
        bool missing[CPT.size()]; 
        for(int i=0;i<CPT.size();i++){
            bool missing[i] = false;
            CPT[i]=0;
        } 
        for(int i=0;i<data.size();i++){
            int valVar = data[i][counter]; 
            index = getIndex(var,valVar,data[i],Alarm);
            if(valVar=="?"){
                missing[index] = true; 
            }
            else{
                if(missing[index]==false) CPT[index] = CPT[index]+1;
            }
            for(int i=0;i<CPT.size();i++){
                if(missing[i]==true) CPT[i] = rand()
                else CPT[i] = CPT[i]/data.size();
            }
        }
        listIt->setCPT(CPT);
        counter = counter+1;
    } 
}
*/