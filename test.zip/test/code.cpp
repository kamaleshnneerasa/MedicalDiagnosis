#include <iostream>
#include <list>
#include <string>
#include <vector>
#include <cstdlib>
#include <random>
#include <iterator>
#include <unordered_map>
#include "Network.h"

using namespace std;

Network Alarm;
vector<pair<vector<string>,float>> data;
//int dataSize = -1;

void Estep();
void Mstep();
void extractData();
void initialize();
void output();
void read_network();
float randomFloat();
vector<float> randomList (int n);
int getCPTIndex(int nodeIndex, vector<string> instance);

void printProb(){
	for(int i =0 ; i<data.size(); i++)
		cout << data[i].second << "\n";
}

int main(){    
    read_network();
    cout<<"read Network"<<"\n";
    //pair<vector<pair<vector<string>,float>>,int> data1 = getData(Alarm);
    extractData();
    cout<<"read data"<<"\n";
    initialize();
    cout<<"intatiated CPTs"<<"\n";
    //printProb();
    int numIter = 0;
    cout << "number of iterations?\n";
    cin >> numIter;
    while(numIter--){
        Estep();
        Mstep();
        cout<<"iteration  "<<numIter<<" ";
    }
    output();
}

//We are calculating the data given the marginal distribultion
void Estep(){
    for(vector<pair<vector<string>,float>>::iterator ptr = data.begin(); ptr != data.end(); ptr++){
    	//cout << ptr->second << "\n"; 
        if(ptr->second >= 0)
            continue;
        int varPst = -1; 
        for(int i =0; i< (signed)ptr->first.size(); i++){
            if(ptr->first[i]=="\"?\""){
                varPst = i;
                break;
            }
        }
        list<Graph_Node>::iterator node =  Alarm.get_nth_node(varPst);
        int nValues = node->get_nvalues();

        for(int i = 0; i< nValues; i++){
        	ptr += 1;
            int index = getCPTIndex(varPst, ptr->first);
            ptr->second = node->get_CPT()[index];
            //cout << ptr->second << "\n";
        }
    }
}

//We are calculting the marginal distributions given the data
void Mstep(){
    //list<Graph_Node> Pres_Graph = Alarm.Pres_Graph;
    int nodesNum = Alarm.netSize(); 
    list<Graph_Node>::iterator listIt = Alarm.get_nth_node(0);
    int index = -1;
    int counter = 0;

    for(int i =0; i < nodesNum; i++, listIt++){
	    string var = listIt->get_name();
        int nvalues = listIt->get_nvalues();
        vector<float> CPT = listIt->get_CPT();
        for(int j=0; j<CPT.size(); j++){
            CPT[j]=0;
        }
    	
    	vector<int> * knownFreq = listIt->get_knownFreq(); 
    	vector<float> freq(CPT.size());
    	for(int j =0; j < freq.size(); j++)
    		freq[j] = (*knownFreq)[j];

    	unordered_map<int, int>* unknownIndex = listIt->get_unknownFreq();

    	//in unoredered_map : key(first) is line number in data; value(second) is index of line in CPT
    	for(auto j : *unknownIndex){
    		freq[j.second] += data[j.first].second;
    	}


        int parentsValues = CPT.size()/nvalues;

        for(int j =0; j < parentsValues; j++){
        	float sum = 0;
        	for(int k =0; k < nvalues; k++)
        		sum += freq[k*parentsValues + j];

        	for(int k =0; k < nvalues; k++)
        		CPT[k*parentsValues + j] = freq[k*parentsValues + j]/sum;
        	 
        }
        
        listIt->set_CPT(CPT);
        counter = counter+1;
    }
}

//Reads the data from the file and returns in a dataStructure
void extractData(){
	data.reserve(11000);
    ifstream inFile;
    inFile.open("records.dat");
    string val;
    //vector<pair<vector<string>,float>> data;
    //int dataSize = 0;
    //cout<<"Flag2"<<"\n";
    int lineNumInData = -1;
    int nodesNum = Alarm.netSize();

    if(inFile.is_open()){        
        while(!inFile.eof()){
        	vector<string> instance;
        	list<Graph_Node>::iterator nodePtr = Alarm.get_nth_node(0);
            int flag = -1;
            //cout<<"Flag3"<<"\n";
            for(int i=0; i < nodesNum; i++){
                inFile>> val;
                if(val=="\"?\"") flag = i; 
                instance.push_back(val);                
            }
            //cout << flag << "\n";
           // cout<<"Flag4"<<"\n";

            if(flag <0){
            	data.push_back({instance,(float)1});
            	lineNumInData += 1;
            	for(int i =0; i<nodesNum; i++, nodePtr++){
            		nodePtr->add_line(lineNumInData, true, getCPTIndex(i, instance));
            	//nodePtr->add_line(lineNumInData, true, 0);
            	}
            }
            else{
            	data.push_back({instance,(float)-1});
            	lineNumInData += 1;
            	list<Graph_Node>::iterator listIt = Alarm.get_nth_node(flag);
                vector<string> values = listIt->get_values();

                vector<string> temp = instance;
                
                for(int i=0;i<values.size();i++){                    
                    temp[flag] = values[i];
                    data.push_back({temp,(float)0});
                    lineNumInData += 1;

                    for(int i =0; i<nodesNum; i++, nodePtr++){
                    	//nodePtr->add_line(lineNumInData, false, 0);
            			nodePtr->add_line(lineNumInData, false, getCPTIndex(i, temp));
            		}
                }

            }
           // dataSize = dataSize+1;
            // cout<<dataSize<< "\n";
        }
    }

    //return make_pair(result,numLines);
} 

void initialize()
{
    int size = Alarm.netSize();
    for(int i =0; i < size; i++)
    {
        list<Graph_Node>::iterator ptr = Alarm.get_nth_node(i);
        int CPTsize = ptr->get_CPT().size();
        int valuesCount = ptr->get_values().size();
        int parentsValues = CPTsize/valuesCount;

        vector<float> CPTupdate(CPTsize);
        //float sum = 0.0;

        for(int j =0; j < parentsValues; j++)
        {
            vector<float> temp = randomList(valuesCount);
            for(int k = 0; k < valuesCount; k++)
            {
                CPTupdate[k*parentsValues + j] = temp[k];
            }
        }
        ptr->set_CPT(CPTupdate);
    }
}

//Outputs the values to the file
void output(){
	ifstream inputFile("alarm.bif");
	ofstream outputFile("solved_alarm.bif");
	
	string line;
	string words;
	int networkSize = Alarm.netSize();
	list<Graph_Node>::iterator ptr = Alarm.get_nth_node(0);

	if(inputFile.is_open() && outputFile.is_open()){
		while(!inputFile.eof()){
			stringstream ss;
			getline(inputFile, line);
			ss.str(line);

			ss >> words;

			if(words.compare("table") == 0){
				outputFile << "\ttable ";

				vector<float> CPT = ptr->get_CPT();
				for(int i =0; i< CPT.size(); i++){
					outputFile << CPT[i] << " ";
					// cout << CPT[i] << " ";
				}
				ptr++;
				outputFile << ";\n";
				// cout << ";\n";
			} 
			else{
				outputFile << line << "\n"; 
			}			
		}
		inputFile.close();
		outputFile.close();
	}
}

void read_network()
{
    string line;
    int find=0;
    ifstream myfile("alarm.bif"); 
    string temp;
    string name;
    vector<string> values;
    
    if (myfile.is_open())
    {
        while (! myfile.eof() )
        {
            stringstream ss;
            getline (myfile,line);
            
            ss.str(line);
            ss>>temp;
            
            if(temp.compare("variable")==0)
            {                 
                    ss>>name;
                    getline (myfile,line);
                   
                    stringstream ss2;
                    ss2.str(line);
                    for(int i=0;i<4;i++)
                    {                       
                        ss2>>temp;                      
                    }
                    values.clear();
                    while(temp.compare("};")!=0)
                    {
                        values.push_back(temp);
                        
                        ss2>>temp;
                    }
                    Graph_Node new_node(name,values.size(),values);
                    int pos=Alarm.addNode(new_node);
                    
            }
            else if(temp.compare("probability")==0)
            {                    
                    ss>>temp;
                    ss>>temp;
                    
                    list<Graph_Node>::iterator listIt;
                    list<Graph_Node>::iterator listIt1;
                    listIt=Alarm.search_node(temp);
                    int index=Alarm.get_index(temp);
                    ss>>temp;
                    values.clear();
                    while(temp.compare(")")!=0)
                    {
                        listIt1=Alarm.search_node(temp);
                        listIt1->add_child(index);
                        values.push_back(temp);
                        
                        ss>>temp;

                    }
                    listIt->set_Parents(values);
                    getline (myfile,line);
                    stringstream ss2;
                    
                    ss2.str(line);
                    ss2>> temp;
                    
                    ss2>> temp;
                    
                    vector<float> curr_CPT;
                    string::size_type sz;
                    while(temp.compare(";")!=0)
                    {
                        
                        curr_CPT.push_back(atof(temp.c_str()));
                        
                        ss2>>temp;
                    }
                    
                    listIt->set_CPT(curr_CPT);
            }
            else
            {}          
    }
        
        if(find==1)
        myfile.close();
    }
    
    //return Alarm;
}

float randomFloat()
{
    std::random_device dev;
    std::mt19937 rng(dev());
    std::uniform_int_distribution<std::mt19937::result_type> dist6(1,1000000); // distribution in range [1, 6]

    return (float)dist6(rng)/(float) 1000000 ;
}

vector<float> randomList (int n)
{
    vector<float> arr(n);
    float sum = 0;

    for(int i =0; i<(n-1); i++){
        arr[i] = randomFloat();
        sum += arr[i];
    }

    if(sum <= 1){
        arr[n-1] = 1 - sum;
        return arr;
    }

    float factor = (float)((int)sum + 1);
    sum = 0;

    for(int i =0; i<(n-1); i++){
        arr[i] = arr[i]/factor;
        sum += arr[i];
    }

    arr[n-1] = 1 - sum;
    return arr;
}


int getCPTIndex(int nodeIndex, vector<string> instance){
    int index = 0;
    list<Graph_Node>::iterator listIt1 = Alarm.get_nth_node(nodeIndex);
    int nvalues = listIt1->get_nvalues();
    vector<string> values = listIt1->get_values();
    vector<string> parents = listIt1->get_Parents();
    int nParents = parents.size();

    
    string valVar = instance[nodeIndex];
    for(int i=0;i<nvalues;i++){
        if(values[i].compare(valVar) == 0){
            index = index*nvalues + i;
            break;
        }
    }

    for(int i=0;i<nParents;i++){
        int parentId = Alarm.get_index(parents[i]);
        vector<string> parentValues = Alarm.search_node(parents[i])->get_values();
        
        for(int j=0; j < parentValues.size();j++){
            if(values[j]==instance[parentId]){
                index = index*parentValues.size() + j;
                break;
            }
        }
    }
  
    return index;
}
